﻿using System;
namespace Assignment;
class Program{
    public static void Main(string[] args)
    {
        try{
       
        System.Console.WriteLine("Enter number 1");
        double number1;
         double.TryParse(Console.ReadLine(),out number1);
        System.Console.WriteLine("Enter number 2");
        double number2;
        double.TryParse(Console.ReadLine(),out number2);
        System.Console.WriteLine($"Addition {number1+number2}");
        System.Console.WriteLine($"Subtraction {number1-number2}");
        System.Console.WriteLine($"Multiplication {number1*number2}");
        System.Console.WriteLine($"Divison {number1/number2}");
        System.Console.WriteLine($"Modulus {number1/number2}");
        }
        catch(Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
        

    }
}