﻿using System;
namespace Question2;
class Program{
    public static void Main(string[] args)
    {
        try{
        System.Console.WriteLine("Enter  number 1");
        int number1 = int.Parse(Console.ReadLine());
        System.Console.WriteLine("Enter number 2");
        int number2 = int.Parse(Console.ReadLine());
        System.Console.WriteLine("Enter number 3");
        int number3 = int.Parse(Console.ReadLine());
        if(number1 > number2 && number1>number2)
        {
            System.Console.WriteLine($"{number1} is bigger");
        }
        else if(number2>number3)
        {
            System.Console.WriteLine($"{number2} is bigger");
        }
        else{
            System.Console.WriteLine($"{number3} is bigger");
        }
        }
        catch(Exception e)
        {
            System.Console.WriteLine(e.Message);
        }
    }
}