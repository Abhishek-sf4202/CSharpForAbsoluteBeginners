﻿using System;
namespace Question2;
class Program{
    public static void Main(string[] args)
    {
        int[] number = new int[10];
        System.Console.WriteLine("Enter 10 numbers");
        for(int i=0;i<10;i++)
        {
            number[i] = int.Parse(Console.ReadLine());
        }
        System.Console.WriteLine("Even numbers");
         for(int i=0;i<10;i++)
        {
            if(number[i]%2 == 0)
            {
                System.Console.Write(number[i]+" ");
            }

        }
       
        System.Console.WriteLine();
         System.Console.WriteLine("Odd numbers");
         for(int i=0;i<10;i++)
        {
            if(number[i]%2 != 0)
            {
                System.Console.Write(number[i]+" ");
            }

        }

    }
}