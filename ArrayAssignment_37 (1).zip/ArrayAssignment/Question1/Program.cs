﻿using System;
namespace Question1;
class Program{
    public static void Main(string[] args)
    {
        // 1.Write a program of sorting an array. 
        System.Console.WriteLine("Enter 5 numbers \n");
        // Declare array and accept 5 integer values from the user
        int[] numbers = new int[5];
        for(int i=0;i<5;i++)
        {
            numbers[i]=int.Parse(Console.ReadLine());
        }
        // . Then sort the input in ascending order and display output.
        Array.Sort(numbers);
         for(int i=0;i<5;i++)
        {
          System.Console.Write($"{numbers[i]} \t");
        }
    }
}