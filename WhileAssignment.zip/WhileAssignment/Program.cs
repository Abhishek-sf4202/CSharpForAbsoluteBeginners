﻿using System;
namespace WhileAssignment // Note: actual namespace depends on the project name.
{
    class Program
    {
        static void Main(string[] args)
        {
            bool check1=  true;
            try{
                while(check1){
            System.Console.WriteLine("Which city is capital of India? 1.Chennai 2.Delhi 3.Mumbai 4.Kolkata");
            int val;
            int.TryParse(Console.ReadLine(),out val);
            if(val == 2)
            {
                System.Console.WriteLine("Correct");
            }
            else{
                System.Console.WriteLine("In correct");
            }
            System.Console.WriteLine("Press Y to continue, Press N to close");
            string value = Console.ReadLine().ToUpper();
            
            if(value.Equals("N"))

            {
                check1 = false;
            }
           else if(!value.Equals("Y")){
            System.Console.WriteLine("Enter valid character");
           }
            }
            }
            catch(Exception e)
            {
                System.Console.WriteLine(e.Message);
            }
            
        }
    }
}